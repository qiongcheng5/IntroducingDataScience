#!/bin/sh

##############################################################################################################
# Usage:
#     codes/generateBubbleChartByJSV1.sh ${Tab-separated input file} ${HTML file embedding chart} ${year}
#
# Format of the input file ${Tab-separated input file}: Country Income-type Income LifeSpan Population Region
#
##############################################################################################################
infile=$1  #Countries-IncomesVsLifeExp-2012.txt

outfile=$2  #Countries-IncomesVsLifeExp-2012.html
rm -f ${outfile}

year=$3

echo "<head>" > ${outfile}
echo "<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>" >> ${outfile}

echo "  <script type=\"text/javascript\">" >> ${outfile} 
echo "    google.charts.load(\"current\", {packages:[\"corechart\"]});" >> ${outfile} 
echo "    google.charts.setOnLoadCallback(drawChart);" >> ${outfile} 
echo "    function drawChart() {" >> ${outfile} 
echo "      var data = google.visualization.arrayToDataTable([" >> ${outfile} 
echo "        ['ID', 'Income', 'Lifespan', 'Region',     'Population']," >> ${outfile}

for line in `cat ${infile} | awk ' { if (NR>1) print $0 } ' | tr '\t' '&' | tr ' ' '@'`; do
    country=`echo "${line}" | awk -F'&' ' { printf "%s", $1 } '  | tr '@' ' ' | tr '&' '\t'`
    income=`echo "${line}" | awk -F'&' ' { printf "%.2f", $3 } ' | tr '@' ' ' | tr '&' '\t'`
    lifespan=`echo "${line}" | awk -F'&' ' { printf "%.2f", $4 } '`
    population=`echo "${line}" | awk -F'&' ' { printf "%d", $5 } '`
    region=`echo "${line}" | awk -F'&' ' { printf "%s", $6 } '`

    echo "        ['${country}',   ${income} , ${lifespan},      '${region}',  ${population}]," >> ${outfile} 
    
done

echo "      ]);" >> ${outfile} 
echo "      var options = {" >> ${outfile} 
echo "        title: 'Correlation between income and lifespan ' +" >> ${outfile} 
echo "               'and population of some world countries (${year})'," >> ${outfile} 
echo "        hAxis: {title: 'Income'}," >> ${outfile} 
echo "        vAxis: {title: 'Lifespan'}," >> ${outfile} 
echo "        bubble: {" >> ${outfile} 
echo "          textStyle: {" >> ${outfile} 
echo "            fontSize: 12," >> ${outfile} 
echo "            fontName: 'Times-Roman'," >> ${outfile} 
echo "            color: 'green'," >> ${outfile} 
echo "            bold: true," >> ${outfile} 
echo "            italic: true" >> ${outfile} 
echo "          }" >> ${outfile} 

echo "        }" >> ${outfile} 
echo "      };" >> ${outfile} 
echo "      var chart = new google.visualization.BubbleChart(document.getElementById('textstyle'));" >> ${outfile} 
echo "      chart.draw(data, options);" >> ${outfile} 
echo "    }" >> ${outfile} 
echo "  </script>" >> ${outfile} 
echo "</head>" >> ${outfile} 
echo "<body>" >> ${outfile} 
echo "  <div id=\"textstyle\" style=\"width: 900px; height: 500px;\"></div>" >> ${outfile} 
echo "</body>" >> ${outfile} 
echo "</html>" >> ${outfile} 
